package com.arshaa.emp.model;



public class ResponseFile {



private String name;
private byte[] url;
private String type;
private long size;



public String getName() {
return name;
}



public void setName(String name) {
this.name = name;
}



public byte[] getUrl() {
return url;
}



public void setUrl(byte[] bs) {
this.url = bs;
}



public String getType() {
return type;
}



public void setType(String type) {
this.type = type;
}



public long getSize() {
return size;
}



public void setSize(long size) {
this.size = size;
}



public ResponseFile(String name, byte[] url, String type, long size) {
super();
this.name = name;
this.url = url;
this.type = type;
this.size = size;



}



public ResponseFile() {
super();
// TODO Auto-generated constructor stub
}



}
