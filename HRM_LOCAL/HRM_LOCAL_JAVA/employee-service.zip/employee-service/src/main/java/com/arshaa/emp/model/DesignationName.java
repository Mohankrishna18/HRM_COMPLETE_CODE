package com.arshaa.emp.model;

public class DesignationName {

	private String designationName;

	public String getDesignationName() {
		return designationName;
	}

	public void setDesignationName(String designationName) {
		this.designationName = designationName;
	}

}
