package com.arshaa.emp.model;

public class StringConstants {

	public final String POST_SUCCESS="Added successfully";
	public final String DUBLICATE_DATA="Data already exist";
	public final String FAILURE_RESPONSE="Something went wrong";
	public final String GET_RESPONSE="Fetching the data";
	public final String PUT_RESPONSE="updated successfully";
	public final String DELETE_RESPONSE="Deleted successfully";
	public final String INVALID_DATA="Invalid ";
	public final String NO_ENTRIES_FOUND="Data not found";
	public StringConstants() {
		// TODO Auto-generated constructor stub
	}

}
