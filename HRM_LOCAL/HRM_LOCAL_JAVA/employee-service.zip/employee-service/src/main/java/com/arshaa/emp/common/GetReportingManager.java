package com.arshaa.emp.common;

public class GetReportingManager {

	private String reportingmanager;

	public String getReportingmanager() {
		return reportingmanager;
	}

	public void setReportingmanager(String reportingmanager) {
		this.reportingmanager = reportingmanager;
	}
	
}
