package com.arshaa.emp.model;

import javax.persistence.Column;

public class EmployeeName {

	private String employeeName;

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	
		

}


