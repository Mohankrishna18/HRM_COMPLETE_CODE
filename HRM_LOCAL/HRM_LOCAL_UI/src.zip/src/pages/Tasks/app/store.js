import { configureStore } from '@reduxjs/toolkit';
//import todoReducer from '../slices/todoslices';
import { todoReducer1 } from '../reducers/reducer';

// export const store = configureStore({
//   reducer: {
//     todos: todoReducer1,
//   },
// })