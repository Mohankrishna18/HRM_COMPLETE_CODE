// import React from "react";
// import { Table } from "react-bootstrap";

// const EmpAttendanceTable = () => {
//   return (
//     <div>
//       <Table striped bordered hover>
//         <thead>
//           <tr>
//             <th>#</th>
//             <th>Date</th>
//             <th>Punch In</th>
//             <th>Punch Out</th>
//             <th>Production</th>
//             <th>Break</th>
//             <th>Overtime</th>
//           </tr>
//         </thead>
//         <tbody>
//           <tr>
//             <td>1</td>
//             <td>19 Apr 2020</td>
//             <td>10.00AM</td>
//             <td>7PM</td>
//             <td>9 hrs</td>
//             <td>1 hr</td>
//             <td>0</td>
//           </tr>
//           <tr>
//             <td>2</td>
//             <td>18 Apr 2020</td>
//             <td>10.00AM</td>
//             <td>7PM</td>
//             <td>9 hrs</td>
//             <td>1 hr</td>
//             <td>0</td>
//           </tr>
//         </tbody>
//       </Table>
//     </div>
//   );
// };

// export default EmpAttendanceTable;
