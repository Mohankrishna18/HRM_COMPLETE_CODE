import React from 'react';
import EmployeeAttendance from './Components/EmployeeAttendance';





const EmployeeAttendenceMain = () => {

    return (

        <div>

            <EmployeeAttendance />

        </div>

    )

}



export default EmployeeAttendenceMain