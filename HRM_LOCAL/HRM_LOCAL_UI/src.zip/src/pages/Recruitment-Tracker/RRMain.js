import React from 'react'
import RRTable from './RecruitmentRequestComponents/RRTable'
function RRMain() {
  return (
    <div><RRTable/></div>
  )
}

export default RRMain;
