import React from 'react'

// import OverAllGraphs from './GraphBars/OverAllGraphs'
// import FinalPMOCards from './RR-Cards/FinalPMOCards'
import RRTabs from './RR-Tabs/RR-Tabs'



const PMO_Dashboard = () => {
    return (
        <div>
            <RRTabs/>

            {/* <FinalPMOCards/>

            <OverAllGraphs/> */}
        </div>
    )
}

export default PMO_Dashboard