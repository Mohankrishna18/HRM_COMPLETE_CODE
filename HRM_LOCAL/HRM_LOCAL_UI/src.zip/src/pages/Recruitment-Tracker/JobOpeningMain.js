import React from 'react'
import JobOpeningTable from './JobOpenings/JobOpeningTable'
function JobOpeningMain() {
  return (
    <div><JobOpeningTable/></div>
  )
}

export default JobOpeningMain