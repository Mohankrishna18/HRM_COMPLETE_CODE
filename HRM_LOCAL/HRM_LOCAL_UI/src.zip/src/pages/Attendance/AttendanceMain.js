import React from 'react'

import Appcom from "./AttendanceComponents/Appcom";

const AttendanceMain= () => {

  return (

    <div>
        <Appcom/>
    </div>

  )

}



export default AttendanceMain;