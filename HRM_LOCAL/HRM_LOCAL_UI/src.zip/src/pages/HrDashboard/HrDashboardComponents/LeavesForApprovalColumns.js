export const forApproval = {
  headers: [
    { title: "EmployeeID", field: "employeeId" },

    { title: "Name", field: "firstName" },

    { title: "Department", field: "departmentName" },

    { title: "Designation", field: "designationName" },

    { title: "Leaves Reason", field: "leaveReason" },

    { title: "No.of Days", field: "numberOfDays" },
  ],
};
