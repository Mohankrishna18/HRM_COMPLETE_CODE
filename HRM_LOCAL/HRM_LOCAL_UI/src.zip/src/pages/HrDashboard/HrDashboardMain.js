import React from 'react';
import HrDashboardTabs from './HrDashboardComponents/HrDashboardTabs';


function HrDashboardMain() {
  return (
    <div>
        <HrDashboardTabs/>

    </div>
  )
}

export default HrDashboardMain;