// import React from "react";

// import { Card, Container, Row, Col, Table } from "react-bootstrap";


// function ProfileTab() {

//     return (
//         <Container style={{ paddingTop: 20 }}>
//             <Row>
//                 <Col>
//                     <Card style={{ padding: 30 }}>
//                         <Card.Title >
//                             <h5>Personal Information:</h5>
//                         </Card.Title>
//                         <Card.Body style={{ paddingLeft: 20, paddingBottom: 40 }} >
//                             <Card.Subtitle style={{ padding: 10 }}>Passport No:</Card.Subtitle>
//                             <Card.Subtitle style={{ padding: 10 }}>Passport Exp Date:</Card.Subtitle>
//                             <Card.Subtitle style={{ padding: 10 }}>Phone:</Card.Subtitle>
//                             <Card.Subtitle style={{ padding: 10 }}>Nationality:</Card.Subtitle>
//                             <Card.Subtitle style={{ padding: 10 }}>Religion:</Card.Subtitle>
//                             <Card.Subtitle style={{ padding: 10 }}>Marital Status:</Card.Subtitle>
//                             <Card.Subtitle style={{ padding: 10 }}>Employment of spouse:</Card.Subtitle>
//                             <Card.Subtitle style={{ padding: 10 }}>No. of Children:</Card.Subtitle>
//                         </Card.Body>
//                     </Card>
//                 </Col>
//                 <Col>
//                     <Card style={{ padding: 30 }}>
//                         <Card.Title >
//                             <h5>Emergency Contact:</h5>
//                         </Card.Title>
//                         <Card.Body style={{ paddingLeft: 20 }} >
//                             <Card.Subtitle style={{ padding: 10 }}><h5>Primary:</h5></Card.Subtitle>
//                             <Card.Subtitle style={{ padding: 10 }}>Name:</Card.Subtitle>
//                             <Card.Subtitle style={{ padding: 10 }}>Relationship:</Card.Subtitle>
//                             <Card.Subtitle style={{ padding: 10 }}>phone:</Card.Subtitle>
//                             <Card.Subtitle style={{ padding: 10 }}><h5>Secondary:</h5></Card.Subtitle>
//                             <Card.Subtitle style={{ padding: 10 }}>Name:</Card.Subtitle>
//                             <Card.Subtitle style={{ padding: 10 }}>Relationship:</Card.Subtitle>
//                             <Card.Subtitle style={{ padding: 10 }}>phone:</Card.Subtitle>
//                         </Card.Body>
//                     </Card>
//                 </Col>
//             </Row>
//             <Row>
//                 <Col>
//                     <Card style={{ padding: 30, marginTop: 20 }}>

//                         <Card.Title >
//                             <h5>Bank Information:</h5>
//                         </Card.Title>
//                         <Card.Body style={{ paddingLeft: 20 }} >
//                             <Card.Subtitle style={{ padding: 10 }}>Bank name:</Card.Subtitle>
//                             <Card.Subtitle style={{ padding: 10 }}>Bank Account No:</Card.Subtitle>
//                             <Card.Subtitle style={{ padding: 10 }}>IFSC Code:</Card.Subtitle>
//                             <Card.Subtitle style={{ padding: 10 }}>PAN No:</Card.Subtitle>
//                         </Card.Body>
//                     </Card>
//                 </Col>
//                 <Col>
//                     <Card style={{ padding: 30, marginTop: 20, paddingBottom: 145 }}>

//                         <Card.Title >
//                             <h5>Family Information:</h5>   </Card.Title>
//                         <Table>
//                             <thead>
//                                 <tr>
//                                     <th>Name</th>
//                                     <th>Relationship</th>
//                                     <th>Date of Birth</th>
//                                     <th>Phone</th>
//                                 </tr>
//                             </thead>
//                             <tbody>
//                             </tbody>
//                         </Table>
//                     </Card>
//                 </Col>
//             </Row>
//             <Row>
//                 <Col>
//                     <Card style={{ padding: 30, marginTop: 20 }}>

//                         <Card.Title >
//                             <h5>Educational Information:</h5>
//                         </Card.Title>
//                         <Card.Body style={{ paddingLeft: 20 }} >
//                         </Card.Body>
//                     </Card>
//                 </Col>
//                 <Col>
//                     <Card style={{ padding: 30, marginTop: 20 }}>

//                         <Card.Title >
//                             <h5>Experience:</h5>
//                         </Card.Title>
//                         <Card.Body style={{ paddingLeft: 20 }} >
//                         </Card.Body>
//                     </Card>
//                 </Col>
//             </Row>
//         </Container>
//     );
// }
// export default ProfileTab;


