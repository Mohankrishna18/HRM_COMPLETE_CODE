// import React from "react";
// import { Row, Col, Navbar, Container} from "react-bootstrap";
// import AddRole from "./AddRole";




// const RolesCard = () => {
//   return (
//     <div>
//       <Row>
//         <Col md={12}>
//         </Col>
//         <AddRole />
//       </Row>
//     </div>
//   );
// };
// export default RolesCard;
