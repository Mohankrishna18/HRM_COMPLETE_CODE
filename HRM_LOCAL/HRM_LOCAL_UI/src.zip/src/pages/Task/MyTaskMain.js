
import React from 'react'
import { Col, Row } from 'react-bootstrap';

import MyTask from './MyTaskComponents/MyTask';


//vipul
const MyTaskMain = () => {
  return (
    <div>
      <Row>
        <Col>

            <MyTask/>
          
           
        </Col>
      </Row>
    </div>
  )
}


export default MyTaskMain;
