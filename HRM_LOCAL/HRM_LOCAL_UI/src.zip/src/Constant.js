
export const BASE_URL = "http://15.206.247.212:6065";