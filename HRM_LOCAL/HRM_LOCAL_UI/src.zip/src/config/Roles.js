//below are the roles of the employees that my application would be accessed by
export default {
    hrmanager:'hrmanager',
    employee:'employee',
    ceo:'ceo',
    taa:'taa',
    taahead:'taahead',
    buhead:'buhead',
    pmohead:'pmohead',
    it:'it',
    manager:'manager',
    recruitmentmanager:'recruitmentmanager',
    irm:'irm',
    srm:'srm',
    
};